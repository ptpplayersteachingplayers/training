<?php
/**
 * Template: Find Trainers v29.5.1
 * Logo + Mobile Optimized with Google Maps integration
 */
defined('ABSPATH') || exit;

$google_maps_api_key = get_option('ptp_google_maps_api_key', '');
$logo_url = PTP_Images::logo();

global $wpdb;
$trainers = $wpdb->get_results("
    SELECT t.*, COALESCE(AVG(r.rating), 5.0) as average_rating, COUNT(r.id) as review_count
    FROM {$wpdb->prefix}ptp_trainers t
    LEFT JOIN {$wpdb->prefix}ptp_reviews r ON t.id = r.trainer_id
    WHERE t.status = 'active'
    GROUP BY t.id
    ORDER BY t.is_featured DESC, average_rating DESC
");

$level_labels = array('pro'=>'PRO','college_d1'=>'D1','college_d2'=>'D2','college_d3'=>'D3','academy'=>'ACADEMY','semi_pro'=>'SEMI-PRO');

$trainers_json = array();
foreach ($trainers as $t) {
    $trainers_json[] = array(
        'id' => (int)$t->id,
        'name' => $t->display_name,
        'slug' => $t->slug,
        'photo' => $t->photo_url ?: PTP_Images::avatar($t->display_name, 400),
        'headline' => $t->headline ?: ($t->college ?: 'Soccer Trainer'),
        'rate' => (int)($t->hourly_rate ?: 70),
        'rating' => $t->average_rating ? round((float)$t->average_rating, 1) : 5.0,
        'reviews' => (int)$t->review_count,
        'lat' => $t->latitude ? (float)$t->latitude : null,
        'lng' => $t->longitude ? (float)$t->longitude : null,
        'location' => trim(($t->city ?: '') . ', ' . ($t->state ?: ''), ', ') ?: 'Philadelphia Area',
        'featured' => !empty($t->is_featured),
        'level' => isset($level_labels[$t->playing_level]) ? $level_labels[$t->playing_level] : '',
        'college' => $t->college ?: '',
    );
}
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
*{box-sizing:border-box;margin:0;padding:0}html,body{overflow-x:hidden!important;max-width:100vw}
.ptp-find{font-family:'Inter',-apple-system,sans-serif;background:#fff;min-height:100vh;color:#111;-webkit-font-smoothing:antialiased}
.ptp-find *{box-sizing:border-box}.ptp-find img{max-width:100%;height:auto}

/* Layout */
.ptp-f-layout{display:flex;min-height:calc(100vh - 140px)}
.ptp-f-panel{width:100%;overflow-y:auto;padding:20px;background:#fff}
.ptp-f-map{display:none;flex:1;min-height:400px;background:#E5E7EB;position:sticky;top:0;height:calc(100vh - 140px)}

@media(min-width:1024px){
    .ptp-f-panel{width:600px;min-width:600px;border-right:1px solid #E5E7EB;height:calc(100vh - 140px)}
    .ptp-f-map{display:block}
}
@media(min-width:1280px){.ptp-f-panel{width:700px;min-width:700px}}

/* Cards */
.ptp-f-grid{display:grid;grid-template-columns:1fr;gap:20px}
@media(min-width:500px){.ptp-f-grid{grid-template-columns:repeat(2,1fr)}}

.ptp-f-card{display:block;text-decoration:none;color:inherit;border-radius:16px;overflow:hidden;background:#fff;box-shadow:0 1px 3px rgba(0,0,0,0.06);transition:all 0.2s}
.ptp-f-card:hover{box-shadow:0 12px 32px rgba(0,0,0,0.12);transform:translateY(-4px)}

/* Filters */
@media(max-width:768px){
    .ptp-f-filters{flex-wrap:wrap!important;gap:8px!important}
    .ptp-f-filter{padding:8px 14px!important;font-size:13px!important}
    .ptp-f-header{flex-direction:column!important;align-items:stretch!important;gap:12px!important}
    .ptp-f-sort{margin-left:0!important}
    .ptp-f-logo{display:block!important}
}
.ptp-f-logo{display:none}
</style>

<div class="ptp-find">
    <!-- Header / Filters -->
    <div style="border-bottom:1px solid #E5E7EB;background:#fff;padding:16px 20px">
        <div class="ptp-f-header" style="display:flex;align-items:center;gap:16px;max-width:1400px;margin:0 auto">
            <!-- Mobile Logo -->
            <a href="<?php echo esc_url(home_url('/training/')); ?>" class="ptp-f-logo" style="flex-shrink:0">
                <img src="<?php echo esc_url($logo_url); ?>" alt="PTP Soccer" style="height:36px;max-width:140px;width:auto;object-fit:contain">
            </a>
            <div class="ptp-f-filters" style="display:flex;gap:8px;flex-wrap:wrap;flex:1">
                <button onclick="ptpFilter('all')" class="ptp-f-filter" data-filter="all" style="display:inline-flex;align-items:center;gap:6px;padding:10px 18px;border:1px solid #111;border-radius:24px;font-size:14px;font-weight:600;background:#111;color:#fff;cursor:pointer;font-family:inherit">All Trainers</button>
                <button onclick="ptpFilter('featured')" class="ptp-f-filter" data-filter="featured" style="display:inline-flex;align-items:center;gap:6px;padding:10px 18px;border:1px solid #E5E7EB;border-radius:24px;font-size:14px;font-weight:500;background:#fff;color:#374151;cursor:pointer;font-family:inherit">⭐ Featured</button>
                <button onclick="ptpFilter('d1')" class="ptp-f-filter" data-filter="d1" style="display:inline-flex;align-items:center;gap:6px;padding:10px 18px;border:1px solid #E5E7EB;border-radius:24px;font-size:14px;font-weight:500;background:#fff;color:#374151;cursor:pointer;font-family:inherit">D1 Athletes</button>
                <button onclick="ptpFilter('pro')" class="ptp-f-filter" data-filter="pro" style="display:inline-flex;align-items:center;gap:6px;padding:10px 18px;border:1px solid #E5E7EB;border-radius:24px;font-size:14px;font-weight:500;background:#fff;color:#374151;cursor:pointer;font-family:inherit">Pro Players</button>
            </div>
            <div class="ptp-f-sort" style="display:flex;align-items:center;gap:8px;font-size:14px;color:#6B7280">
                <span>Sort:</span>
                <select id="ptp-sort" onchange="ptpSort()" style="padding:10px 14px;border:1px solid #E5E7EB;border-radius:8px;font-size:14px;background:#fff;color:#111;cursor:pointer;font-family:inherit">
                    <option value="rating">Top Rated</option>
                    <option value="price_low">Price: Low to High</option>
                    <option value="price_high">Price: High to Low</option>
                    <option value="reviews">Most Reviews</option>
                </select>
            </div>
        </div>
    </div>

    <!-- Search Bar -->
    <div style="background:#0E0F11;padding:24px 20px">
        <div style="max-width:800px;margin:0 auto">
            <div style="display:flex;gap:12px;flex-wrap:wrap">
                <div style="flex:1;min-width:200px;display:flex;align-items:center;gap:12px;padding:14px 18px;background:#fff;border-radius:12px">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                    <input type="text" id="ptp-search" placeholder="Search trainers..." oninput="ptpSearch()" style="border:none;background:transparent;font-size:16px;width:100%;outline:none;font-family:inherit">
                </div>
                <div style="display:flex;align-items:center;gap:12px;padding:14px 18px;background:#fff;border-radius:12px;min-width:180px">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <select id="ptp-location" onchange="ptpSearch()" style="border:none;background:transparent;font-size:16px;width:100%;outline:none;font-family:inherit;cursor:pointer">
                        <option value="">All Locations</option>
                        <option value="PA">Pennsylvania</option>
                        <option value="NJ">New Jersey</option>
                        <option value="DE">Delaware</option>
                        <option value="MD">Maryland</option>
                        <option value="NY">New York</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Main Layout -->
    <div class="ptp-f-layout">
        <!-- Trainer List Panel -->
        <div class="ptp-f-panel">
            <div style="margin-bottom:20px">
                <h1 style="font-size:24px;font-weight:700;margin:0 0 4px;color:#111">Find a Trainer</h1>
                <p id="ptp-count" style="font-size:14px;color:#6B7280;margin:0"><?php echo count($trainers); ?> trainers available</p>
            </div>

            <div class="ptp-f-grid" id="ptp-trainers">
                <?php foreach ($trainers as $t): 
                    $photo = $t->photo_url ?: 'https://ui-avatars.com/api/?name=' . urlencode($t->display_name) . '&size=400&background=FCB900&color=0E0F11';
                    $rate = (int)($t->hourly_rate ?: 70);
                    $rating = number_format((float)$t->average_rating, 1);
                    $level = isset($level_labels[$t->playing_level]) ? $level_labels[$t->playing_level] : '';
                    $location = trim(($t->city ?: '') . ', ' . ($t->state ?: ''), ', ') ?: 'Philadelphia Area';
                    $profile_url = home_url('/trainer/' . $t->slug . '/');
                ?>
                <a href="<?php echo esc_url($profile_url); ?>" class="ptp-f-card" 
                   data-name="<?php echo esc_attr(strtolower($t->display_name)); ?>"
                   data-level="<?php echo esc_attr($t->playing_level); ?>"
                   data-featured="<?php echo $t->is_featured ? '1' : '0'; ?>"
                   data-rate="<?php echo $rate; ?>"
                   data-rating="<?php echo $rating; ?>"
                   data-reviews="<?php echo (int)$t->review_count; ?>"
                   data-state="<?php echo esc_attr($t->state); ?>">
                    <div style="position:relative;aspect-ratio:4/5;overflow:hidden;background:#f3f4f6">
                        <img src="<?php echo esc_url($photo); ?>" alt="<?php echo esc_attr($t->display_name); ?>" style="width:100%;height:100%;object-fit:cover;transition:transform 0.3s" loading="lazy">
                        <div style="position:absolute;bottom:0;left:0;right:0;height:50%;background:linear-gradient(to top,rgba(0,0,0,0.7),transparent)"></div>
                        <?php if ($level): ?>
                        <div style="position:absolute;top:12px;left:12px;padding:5px 12px;background:#FCB900;color:#0E0F11;font-size:11px;font-weight:700;border-radius:8px"><?php echo esc_html($level); ?></div>
                        <?php endif; ?>
                        <?php if ($t->is_featured): ?>
                        <div style="position:absolute;top:12px;right:12px;padding:5px 10px;background:#8B5CF6;color:#fff;font-size:10px;font-weight:700;border-radius:6px">FEATURED</div>
                        <?php endif; ?>
                        <div style="position:absolute;bottom:16px;left:16px;right:60px;color:#fff">
                            <div style="font-size:18px;font-weight:700;margin-bottom:4px;display:flex;align-items:center;gap:6px">
                                <?php echo esc_html($t->display_name); ?>
                                <?php if ($t->is_verified): ?>
                                <span style="width:18px;height:18px;background:#3B82F6;border-radius:50%;display:inline-flex;align-items:center;justify-content:center"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg></span>
                                <?php endif; ?>
                            </div>
                            <div style="font-size:14px;opacity:0.9">$<?php echo $rate; ?>/hour</div>
                        </div>
                        <div style="position:absolute;bottom:16px;right:16px;width:40px;height:40px;background:#FCB900;border-radius:50%;display:flex;align-items:center;justify-content:center">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#0E0F11" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                        </div>
                    </div>
                    <div style="padding:14px 16px">
                        <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
                            <span style="font-size:14px;font-weight:600;color:#111">⚽ Soccer</span>
                            <?php if ($t->review_count > 0): ?>
                            <span style="display:flex;align-items:center;gap:4px;font-size:14px;color:#111">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="#FCB900"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                <?php echo $rating; ?>
                                <span style="color:#6B7280">(<?php echo $t->review_count; ?>)</span>
                            </span>
                            <?php else: ?>
                            <span style="font-size:13px;color:#8B5CF6;font-weight:600">New</span>
                            <?php endif; ?>
                        </div>
                        <div style="display:flex;flex-wrap:wrap;gap:12px;font-size:13px;color:#6B7280">
                            <span style="display:flex;align-items:center;gap:4px">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                                <?php echo esc_html($location); ?>
                            </span>
                            <span style="display:flex;align-items:center;gap:4px;color:#059669">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                                Available
                            </span>
                        </div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>

            <!-- Empty State -->
            <div id="ptp-empty" style="display:none;text-align:center;padding:60px 20px">
                <div style="width:80px;height:80px;background:#F3F4F6;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px">
                    <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" stroke-width="1.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
                </div>
                <h3 style="font-size:20px;font-weight:700;color:#111;margin:0 0 8px">No trainers found</h3>
                <p style="font-size:15px;color:#6B7280;margin:0">Try adjusting your filters or search terms</p>
            </div>

            <!-- Info Banner -->
            <div style="display:flex;align-items:center;gap:12px;padding:16px;background:#F0F9FF;border:1px solid #BAE6FD;border-radius:12px;margin-top:24px">
                <div style="width:44px;height:44px;background:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#0284C7" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>
                </div>
                <div style="font-size:14px;color:#0C4A6E;line-height:1.5">
                    <strong style="color:#0284C7">All trainers are background checked</strong> and verified NCAA or professional athletes.
                </div>
            </div>
        </div>

        <!-- Map Panel -->
        <div class="ptp-f-map">
            <div id="ptp-map" style="width:100%;height:100%"></div>
            <?php if (empty($google_maps_api_key)): ?>
            <div style="display:flex;align-items:center;justify-content:center;height:100%;color:#6B7280;text-align:center;padding:40px">
                <div>
                    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" style="margin:0 auto 16px;display:block;opacity:0.5"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
                    <p style="margin:0;font-size:15px">Map requires Google Maps API key</p>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
var ptpTrainers = <?php echo json_encode($trainers_json); ?>;
var ptpCurrentFilter = 'all';

function ptpFilter(filter) {
    ptpCurrentFilter = filter;
    document.querySelectorAll('.ptp-f-filter').forEach(function(btn) {
        var isActive = btn.dataset.filter === filter;
        btn.style.background = isActive ? '#111' : '#fff';
        btn.style.color = isActive ? '#fff' : '#374151';
        btn.style.borderColor = isActive ? '#111' : '#E5E7EB';
    });
    ptpSearch();
}

function ptpSort() {
    ptpSearch();
}

function ptpSearch() {
    var query = document.getElementById('ptp-search').value.toLowerCase();
    var state = document.getElementById('ptp-location').value;
    var sort = document.getElementById('ptp-sort').value;
    var cards = document.querySelectorAll('.ptp-f-card');
    var count = 0;

    cards.forEach(function(card) {
        var name = card.dataset.name || '';
        var cardState = card.dataset.state || '';
        var level = card.dataset.level || '';
        var featured = card.dataset.featured === '1';
        var show = true;

        // Text search
        if (query && name.indexOf(query) === -1) show = false;
        
        // State filter
        if (state && cardState !== state) show = false;
        
        // Category filter
        if (ptpCurrentFilter === 'featured' && !featured) show = false;
        if (ptpCurrentFilter === 'd1' && level !== 'college_d1') show = false;
        if (ptpCurrentFilter === 'pro' && level !== 'pro') show = false;

        card.style.display = show ? 'block' : 'none';
        if (show) count++;
    });

    // Sort
    var grid = document.getElementById('ptp-trainers');
    var sorted = Array.from(cards).filter(function(c) { return c.style.display !== 'none'; });
    
    sorted.sort(function(a, b) {
        if (sort === 'price_low') return parseFloat(a.dataset.rate) - parseFloat(b.dataset.rate);
        if (sort === 'price_high') return parseFloat(b.dataset.rate) - parseFloat(a.dataset.rate);
        if (sort === 'reviews') return parseFloat(b.dataset.reviews) - parseFloat(a.dataset.reviews);
        return parseFloat(b.dataset.rating) - parseFloat(a.dataset.rating);
    });

    sorted.forEach(function(card) { grid.appendChild(card); });

    document.getElementById('ptp-count').textContent = count + ' trainer' + (count !== 1 ? 's' : '') + ' available';
    document.getElementById('ptp-empty').style.display = count === 0 ? 'block' : 'none';
}

<?php if (!empty($google_maps_api_key)): ?>
function initMap() {
    var map = new google.maps.Map(document.getElementById('ptp-map'), {
        zoom: 9,
        center: {lat: 39.9526, lng: -75.1652},
        styles: [{"featureType":"all","elementType":"geometry","stylers":[{"color":"#f5f5f5"}]},{"featureType":"water","elementType":"geometry","stylers":[{"color":"#c9c9c9"}]}]
    });
    
    var bounds = new google.maps.LatLngBounds();
    var hasMarkers = false;

    ptpTrainers.forEach(function(t) {
        if (t.lat && t.lng) {
            hasMarkers = true;
            var pos = {lat: t.lat, lng: t.lng};
            bounds.extend(pos);
            
            var marker = new google.maps.Marker({
                position: pos,
                map: map,
                title: t.name,
                icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 12,
                    fillColor: '#FCB900',
                    fillOpacity: 1,
                    strokeColor: '#0E0F11',
                    strokeWeight: 2
                }
            });

            var info = new google.maps.InfoWindow({
                content: '<div style="font-family:Inter,sans-serif;padding:8px;min-width:200px">' +
                    '<div style="font-weight:700;font-size:16px;margin-bottom:4px">' + t.name + '</div>' +
                    '<div style="color:#6B7280;font-size:14px;margin-bottom:8px">' + t.headline + '</div>' +
                    '<div style="display:flex;justify-content:space-between;align-items:center">' +
                    '<span style="font-weight:700;color:#0E0F11">$' + t.rate + '/hr</span>' +
                    '<a href="<?php echo home_url('/trainer/'); ?>' + t.slug + '/" style="background:#FCB900;color:#0E0F11;padding:6px 12px;border-radius:6px;font-size:13px;font-weight:600;text-decoration:none">View</a>' +
                    '</div></div>'
            });

            marker.addListener('click', function() { info.open(map, marker); });
        }
    });

    if (hasMarkers) map.fitBounds(bounds);
}
</script>
<script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo esc_attr($google_maps_api_key); ?>&callback=initMap"></script>
<?php else: ?>
</script>
<?php endif; ?>
